var r = 40;
var g = 144;
var b = 199;

function setup() {
  createCanvas(400, 400);
}

function draw() {
  r = map(mouseX, 0, 600, 0, 255);
  b = map(mouseX, 0, 600, 0, 199);
  background(r, 56, b);
  
  //ellipse
  fill (255);
  ellipse(mouseX, 200, 10, 10);
  
}

