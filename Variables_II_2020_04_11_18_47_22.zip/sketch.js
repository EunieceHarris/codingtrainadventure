//JavaScript Attempt at an Object
var circleX = {
  x:0,
  y: 200,
  diameter: 1,
};

function setup() {
  createCanvas(400, 400);
  
}

function draw() {
  background(220);
  ellipse(circleX.x, circleX.y, circleX.diameter);
  
  circleX.x = circleX.x +3;
  circleX.diameter = circleX.diameter + 1;
}
