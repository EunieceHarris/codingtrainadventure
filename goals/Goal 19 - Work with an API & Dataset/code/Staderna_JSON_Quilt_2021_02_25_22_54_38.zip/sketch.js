let stad; 
 
function setup() {
  createCanvas(400, 400);
  stad = loadJSON('staderna.json', gotData, 'json');

}

function gotData(stad) {
  let stads = stad.length;
  //for (let v = 0; v < stads; v++) {
   // createP(stad[v].Locality);
  //  let lat = floor(stad[v].Latitude);
   // createP(lat);
 // }
 
}

function draw() {
  background(220);
  textSize(40);
    
}