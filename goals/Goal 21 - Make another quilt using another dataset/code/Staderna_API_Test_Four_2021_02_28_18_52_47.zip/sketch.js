

var farg = {
  r:0,
  g:0,
  b:0
}

function setup(){
  createCanvas(600, 800);
  background(20);
  setInterval(tiles, 500);
}

function tiles(){
  for (var w = 0; w < width; w +=120 ){
    for(var h = 0;h < height; h +=160){
      farg.r = random(0, 255);
      farg.b = random(0, 255);
      farg.g = random(0, 255);
      fill(farg.r, farg.g, farg.b);
      noStroke();
      rect(w, h, 120, 160, 30);
      
    }
  }
}

function draw(){

}