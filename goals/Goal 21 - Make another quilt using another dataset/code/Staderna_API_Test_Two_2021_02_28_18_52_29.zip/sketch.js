let stad;
let temp;
let cord;

// Staderna JSON load
function preload(){
  loadJSON('staderna.json', gotDataOne);
}

// Openweather API
let api = 'https://api.openweathermap.org/data/2.5/weather?';
let apiKey = '&APPID=b1e36d66ff1f20d3ea9deb0a88148d80';
let latX;
let longX;
let units = '&units=metric';


function setup() {
  createCanvas(500, 500);
  background(150, 200, 140);
  //noCanvas();
  let cordX = random(0, cord.length);
  for (var x = 0; x < cordX; x++){
    latX = '&lat=' + cord[x].Latitude;
    longX = '&lon=' + cord[x].Longitude;
  
  }
  
  let url = api + latX + longX + apiKey + units;
  loadJSON(url, gotData);
  
}

function gotDataOne(data){
  cord = data;
}

function gotData(data){
  stad = data.main.temp + " C";
  let name = data.name;
  textAlign(CENTER);
  fill(255);
  textSize(32);
  text(stad, 250, 250);
  text(name, 250, 200)
}
