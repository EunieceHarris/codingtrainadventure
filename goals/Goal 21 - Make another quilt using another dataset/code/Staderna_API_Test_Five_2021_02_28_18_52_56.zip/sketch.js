let stadArray = [];

let stad;
let temp;
let cord;

// Staderna JSON load
function preload() {
  loadJSON('staderna.json', gotDataOne);
}

function gotDataOne(data){
  stad = data;
}

// Openweather API
let api = 'https://api.openweathermap.org/data/2.5/weather?';
let apiKey = '&APPID=b1e36d66ff1f20d3ea9deb0a88148d80';
let latX;
let longX;
let units = '&units=metric';

// Random Color Starter

function setup(){
  createCanvas(600, 800);
  background(20);
  // Staderna Variables Initialized
  tiles();
  
}

function tiles(){
  for (var i = 10; i < width; i+= 10){
    for(var j = 10; j < height; j+=25){
      ellipseMode(CENTER);
      noStroke();
      fill(120);
      ellipse(i, j, 5, 5);
    }
  }

}


// Constructor Object Below
function Tiles(){
  // Establish Variables
  let url = api + apiKey + latX + longX + units;
  
  
  // Establish Functions
  this.dot = function(x, y){
    ellipseMode(CENTER);
    noStroke();
    fill(120);
    ellipse(x,y,5, 5)
  }
  
  
  
}