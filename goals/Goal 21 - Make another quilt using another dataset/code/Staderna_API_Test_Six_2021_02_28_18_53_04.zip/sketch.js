// Step 6: Have each dot change color at random.

let stadArray = [];
let tempArray = [];

let stad;
let temp;
let cord;

// Staderna JSON load
function preload() {
  loadJSON('staderna.json', gotDataOne);
}

function gotDataOne(data) {
  stad = data;
}

// Openweather API
let api = 'https://api.openweathermap.org/data/2.5/weather?';
let apiKey = '&APPID=b1e36d66ff1f20d3ea9deb0a88148d80';
let latX;
let longX;
let units = '&units=metric';



function setup() {
  createCanvas(600, 800);
  background(0);

  setInterval(colorTiles, 500);

}

function colorTiles(){
  // Push Objects to Array 
  for (var i = 0; i < stad.length; i++) {
    stadArray[i] = new Tiles();
  }
  
  // Create API url to get temp from lat and long from 
  
  // Draw Each Object from StadArray  

  for (var h = 0; h < 1; h++) {

    for (var k = 10; k < width; k += 10) {
      for (var j = 10; j < height; j += 25) {
        let f = random(0, 4);
        stadArray[h].dot(k, j, f);
      }
    }
  }
}



// Constructor Object Below
function Tiles() {
  // Establish Variables
  //let url = api + apiKey + latX + longX + units;


  // Establish Functions
  this.dot = function(x, y, f) {
    ellipseMode(CENTER);
    stroke(2);
    fill(200);
    if (f < 1.50) {
      noStroke();
      fill(19, 69, 105);
    }
    if (f > 2.50) {
      noStroke();
      fill(39, 99, 143)
    }
    ellipse(x, y, 5, 5)
  }



}