// Sverige Municipalities coordinates
let stad;
let temp;

function preload(){
  stad = loadJSON('staderna.json', gotData, 'json');
}

// Openweather API
let api = "http://api.openweathermap.org/data/2.5/weather?";
let apiKey = "&appid=b1e36d66ff1f20d3ea9deb0a88148d80";
let latX;
let longX;
let unit = '&units=metric';
let apiTwo = 'http://api.openweathermap.org/data/2.5/weather?lat=55.399274&lon=13.600275&appid=b1e36d66ff1f20d3ea9deb0a88148d80&units=metric';

function gotData(data){
  stad = data; 
}

function setup() {
  createCanvas(500, 500);
  for (var i = 0; i < 3; i++){
    latX = 'lat='+ stad[i].Latitude;
    longX = '&lon='+stad[i].Longitude;
  }
  let url = api + latX + longX + apiKey + unit;
  loadJSON(apiTwo, gotDataTwo);
 
}

function gotDataTwo(data){
  weather = data;
}


